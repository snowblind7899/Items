A small program that allows a user to add Items to an ItemStorage, and export their ItemStorage to a CSV file. 
Each Item object is generated with a factory design pattern, with the Item base class being an interface that has its functions implemented in Book, Car, Coin, and Collectible.

To run the program, run Main.java